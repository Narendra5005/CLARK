# I am using one single configuration file to feed all the below details which are needed for the test case. This is aiming at single test case only and we need to take parameterization into the consideration if we want to feed different sets of data

chrome_driver_path = r"C:\Users\npendem\Documents\Narens Docs\Clark_Framework\Clark1\Drivers\chromedriver.exe"
ClarkStageURL = "https://staging.clark.de/de/app/contracts?cv=2"
waitTime = 10

IBAN = "DE55500105174529223988"
REGISTRATION_PASSWORD = "Mummy@123"
REGISTRATION_FIRST_NAME = "Naren"
REGISTRATION_LAST_NAME = "lAST NAME"
REGISTRATION_DOB = "11.01.1990"
REGISTRATION_STREET = "123 street"
REGISTRATION_POSTAL = "60306"
REGISTRATION_HOUSE = "2342"
REGISTRATION_CITY = "FrankFurt"
REGISTRATION_PHONE = "015229320777"

from selenium import webdriver
import configurationfile

chrome_driver_path = configurationfile.chrome_driver_path
URL = configurationfile.ClarkStageURL

global driver
driver = webdriver.Chrome(chrome_driver_path)
driver.maximize_window()

class Base:
    def launchClarkPage(self):
        driver.get(URL)
        driver.implicitly_wait(10)

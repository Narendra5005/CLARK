#This is a common util file which can be imported in all the pages files. This basically contains all the generic imports which are needed for page object implementations

from selenium import webdriver
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.common.by import By
from configurationfile import waitTime as wait
from pages.clark_basePage import driver
